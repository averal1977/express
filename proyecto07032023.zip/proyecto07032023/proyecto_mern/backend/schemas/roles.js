const mongoose = require('mongoose');

const rolesSchema = new mongoose.Schema({
    nombre: {
        type: String,
        required: true
    }
});

const Roles = new mongoose.model('Roles', rolesSchema);

module.exports = Roles;
