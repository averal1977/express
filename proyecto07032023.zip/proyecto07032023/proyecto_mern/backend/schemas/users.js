const mongoose = require('mongoose');

const usersSchema = new mongoose.Schema({
    nombres: {
        type: String,
        required: true,
    },
    email: {
        type: String,
        required: true,
    },    
    password: {
        type: String,
        required: true,
    },
    rol: {
        //type: mongoose.Schema.Types.ObjectId,
        type: String,
        //ref: 'Roles',
        required: true,
      } 
});

const Users = new mongoose.model('Users', usersSchema);

module.exports = Users;
