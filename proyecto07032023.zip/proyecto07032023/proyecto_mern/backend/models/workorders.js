const Orders = require('../schemas/workorders');

function getOrder(cb) {
    Orders.find({})
    .populate("client", "nombres")
    .populate("vehicle")
    .populate("services") 
    .populate("user") 
    .then((elems) => {
        return cb(null, elems);
    })
    .catch((error) => {
        console.log('Error:', error);
        return cb(error);
    })
}

function createOrder(b, cb) {
    new Orders(b)
    .save()
    .then((elem) => {
        return cb(null, elem);
    })
    .catch((error) => {
        console.log('Error:', error);
        return cb(error);
    });
}

function deleteOrder(id, cb) {
    Orders.findOneAndRemove({ _id: id})
    .then((elem) => {
        return cb(null, elem);
    })
    .catch((error) => {
        console.log('Error:', error);
        return cb(error);
    })
}

function updateOrder(id, order, cb) {
    Orders.findOneAndUpdate({ _id: id}, order)
    .then((elem) => {
        return cb(null, elem);
    })
    .catch((error) => {
        console.log('Error:', error);
        return cb(error);
    })
}


exports.getOrder = getOrder;
exports.createOrder = createOrder;
exports.deleteOrder = deleteOrder;
exports.updateOrder = updateOrder;
