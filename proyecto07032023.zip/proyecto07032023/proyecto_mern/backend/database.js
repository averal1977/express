const mongoose = require('mongoose')

//cadena de conexion
const USER = 'veralucio';
const PASSWORD = 'IZMSA6GFlXvkM1HA';
const DATABASE_NAME = 'CarShop';

const URI = process.env.MONGODB_URI
            ? process.env.MONGODB_URI
            : `mongodb+srv://${USER}:${PASSWORD}@cluster0.fsjeuob.mongodb.net/${DATABASE_NAME}?retryWrites=true&w=majority`

mongoose.connect(URI)
.then(() => {
    console.log('Database connected!', URI);
})
.catch((error)=> {
    console.log('Error connecting:', error);
});
