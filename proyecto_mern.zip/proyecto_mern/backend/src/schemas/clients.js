const mongoose = require('mongoose');

const clientsSchema = new mongoose.Schema({
    nombres: {
        type: String,
        required: true,
    },
    email: {
        type: String,
        required: true,
    },    
    celular: {
        type: String,
        required: true,
    },
    identificacionfiscal: {    
        type: String,
        required: true,
    },
    tipoid: {
        type: String,
        required: true,
    },
    clave: {
        type: String,
        required: true,
    }
});

const Clients = new mongoose.model('client', clientsSchema);

module.exports = Clients;
