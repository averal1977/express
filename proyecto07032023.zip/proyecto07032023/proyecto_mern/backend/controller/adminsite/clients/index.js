const express = require('express');
const router = express.Router();

const Clients = require('../../../models/clients');


router.get('/api/clients', (req, res) => {
    return Clients.getClient((error, elems)=> {
        if (error) {
            return res.status(500).json({ code: 'UE', message: 'Unknown error'})
        }
        res.json(elems);
    });
});

router.post('/api/clients', function (req, res){
    const client = req.body;
    console.log('Data:', client);

    return Clients.createClient(client, (error, b) => {
        if(error){
            return  res.status(500).json({ code: 'UE', message: 'Unkwown error'})
        }
        res.json({ code: 'OK', message: 'Saved successfully!', data: b.toJSON()})
    });
});


router.delete('/api/clients/:id', function (req, res){
    console.log('Deleting:', req.params);
    const { id } = req.params;
    
    Clients.deleteClient(id, (error, b) => {
        if (error) {
            return  res.status(500).json({ code: 'UE', message: 'Unkwown error'})
        }
        res.json({ code: 'OK', message: 'Deleted successfully!', data: b.toJSON()})
    });
});

router.put('/api/clients/:id', (req, res) => {
    const client = req.body;
    console.log('Data:', client);
    const {id} = req.params;
    console.log('id', id);
    Orders.updateClient(id, client, (error, b) => {
        if (error) {
            return  res.status(500).json({ code: 'UE', message: 'Unkwown error'})
        }
        res.json({ code: 'OK', message: 'Update successfully!', data: b.toJSON()})
    });
});

module.exports = router;
