const mongoose = require('mongoose');

const ordersSchema = mongoose.Schema({
    estado: {
      type: String,
      required: true,
    },
    fecha_agenda: {
      type: Date,
      required: false,
    },
    motivo_cancela: {
      type: String,
      required: false,
    },    
    client: {
      type: mongoose.Types.ObjectId,
      ref: 'Clients',
      required: true,
    },
    vehicle: {
      type: mongoose.Types.ObjectId,
      ref: 'Vehicles',
      required: true,
    },
    services: [{
      type: String,
      required: true,
    }],
    user: {
      type: mongoose.Types.ObjectId,
      ref: 'Users',
      required: true,
    },    
});

const Orders = new mongoose.model('Orders', ordersSchema);

module.exports = Orders;
