const Services = require('../schemas/services');

function getService(cb) {
    Services.find({})
    .then((elems) => {
        return cb(null, elems);
    })
    .catch((error) => {
        console.log('Error:', error);
        return cb(error);
    })
}

function createService(b, cb) {
    new Services(b)
    .save()
    .then((elem) => {
        return cb(null, elem);
    })
    .catch((error) => {
        console.log('Error:', error);
        return cb(error);
    });
}

function deleteService(id, cb) {
    Services.findOneAndRemove({ _id: id})
    .then((elem) => {
        return cb(null, elem);
    })
    .catch((error) => {
        console.log('Error:', error);
        return cb(error);
    })
}

function updateService(id, service, cb) {
    Orders.findOneAndUpdate({ _id: id}, service)
    .then((elem) => {
        return cb(null, elem);
    })
    .catch((error) => {
        console.log('Error:', error);
        return cb(error);
    })
}

exports.getService = getService;
exports.createService = createService;
exports.deleteService = deleteService;
exports.updateService = updateService;
