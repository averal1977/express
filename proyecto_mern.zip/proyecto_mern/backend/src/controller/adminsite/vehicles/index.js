const express = require('express');
const router = express.Router();

const Vehicles = require('../../../models/vehicles');


router.get('/', (req, res) => {
    return Vehicles.getVehicle((error, elems)=> {
        if (error) {
            return res.status(500).json({ code: 'UE', message: 'Unknown error'})
        }
        res.json(elems);
    });
});

router.post('/', function (req, res){
    const vehicle = req.body;
    console.log('Data:', vehicle);

    return Vehicles.createVehicle(vehicle, (error, b) => {
        if(error){
            return  res.status(500).json({ code: 'UE', message: 'Unkwown error'})
        }
        res.json({ code: 'OK', message: 'Saved successfully!', data: b.toJSON()})
    });
});


router.delete('/:id', function (req, res){
    // const { body: { data } } = res.body;
    console.log('Deleting:', req.params);
    const { id } = req.params;
    
    Vehicles.deleteVehicle(id, (error, b) => {
        if (error) {
            return  res.status(500).json({ code: 'UE', message: 'Unkwown error'})
        }
        res.json({ code: 'OK', message: 'Deleted successfully!', data: b.toJSON()})
    });
});


module.exports = router;
