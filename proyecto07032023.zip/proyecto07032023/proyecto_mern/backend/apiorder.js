const express = require('express');
const app = express();
const engine = require('ejs-locals');
const bodyParser = require('body-parser');
const session = require('express-session');
const path = require('path');

//ejecutar el servidor
const db = require('./database');

const AdminOrderCarShop = require('./controller/adminsite/workorders')
const Auths = require('./models/auths');


//Obtiene login y password de MongoDB Atlas para validar autentication  
let auth ={};
const authDb = Auths.getPassword((error, elems)=> {            
        auth = elems;
        return elems;
    });    
    

app.use(bodyParser.json({ type: 'application/json' }))

app.use((req, res, next) => {
    console.log('Autenticacion Mongo DB', authDb)          
    //const auth = {login: 'yourlogin', password: 'yourpassword'}
    const b64auth = (req.headers.authorization || '').split(' ')[1] || ''
    const [login, password] = Buffer.from(b64auth, 'base64').toString().split(':')
    // Verify login and password are set and correct
    if (login && password && login === auth.login && password === auth.password) {
    // Access granted...
    return next()
    }
    // Access denied...
    res.status(401).send('Authentication required.')
    })
    
app.use('/', AdminOrderCarShop);

app.set('port', process.env.PORT || 3002)
app.listen(3002, () => console.log('Example app listening on port: ', app.get('port')))
