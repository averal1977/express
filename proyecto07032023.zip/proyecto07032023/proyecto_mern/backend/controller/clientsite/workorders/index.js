const express = require('express');
const router = express.Router();

router.get('/', function (req, res) {
    res.render('client/index' , { name: 'Administrator'});
});


router.post('/workorders', function (req, res){
    console.log('Data:', req.body);
    bookings.push(req.body)
    res.json({ code: 'OK', message: 'Saved successfully!'})
});

module.exports = router;