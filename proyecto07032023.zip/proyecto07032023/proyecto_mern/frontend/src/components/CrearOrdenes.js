import React, { useState } from "react";
import axios from 'axios'

const CrearOrdenes = () => {

  const valorInicialCliente = {
    nombres: '',
    email: '',    
    celular: '',
    identificacionfiscal: '',
    tipoid: ''
  }

  const valorInicialVehiculo = {
    marca: '',
    modelo: '',
    placa: '',
    gasolina: '',
    defectos: ''
  }

  const valorInicialOrden = {
    estado: '',
    fecha_agenda: '07/03/2023',
    motivo_cancela: '',    
    client: '',
    vehicle: '',
    services: ['Cambio de aceite',
              'Cambio de frenos',
              'Alineacion y balanceo',
              'Diagnóstico general',
              'Revisión sistema eléctrica',
              'Revisión de la suspensión'
              ],
    user: ''
  }

  const [cliente, setCliente] = useState(valorInicialCliente)
  const [vehiculo, setVehiculo] = useState(valorInicialVehiculo)
  const [orden, setOrden] = useState(valorInicialOrden)

  const capturarDatosCliente = (e) =>{
    const {name, value} = e.target
    setCliente({...cliente, [name]: value})
  }

  const capturarDatosVehiculo = (e) =>{
    const {name, value} = e.target
    setVehiculo({...vehiculo, [name]: value})
  }

  const capturarDatosOrden = (e) =>{
    const {name, value} = e.target
    setOrden({...orden, [name]: value})
  }


  const guardarDatos = async (e) =>{
    e.preventDefault();
 
    let cliente_id = '';
    let vehiculo_id = '';

    //crear logica para la peticion post
    const newCliente = {
      nombres: cliente.nombres,
      email: cliente.email,    
      celular: cliente.celular,
      identificacionfiscal: cliente.identificacionfiscal,
      tipoid: cliente.tipoid  
    }

    axios.post('http://localhost:4000/api/clients', newCliente).then( clienteResponse => {
        //crear_vehiculo()
        const newVehiculo = {
          marca: vehiculo.marca,
          modelo: vehiculo.modelo,
          placa: vehiculo.placa,
          gasolina: vehiculo.gasolina,
          defectos: vehiculo.defectos      
        }
        
       axios.post('http://localhost:4000/api/vehicles', newVehiculo).then(vehiculoResponse => {
        cliente_id = clienteResponse.data.data._id;
        vehiculo_id = vehiculoResponse.data.data._id;
        console.log('id_cliente',cliente_id)
        console.log('id_vehiculo',vehiculo_id)


        const newOrden = {
          estado: orden.estado,
          fecha_agenda: orden.fecha_agenda,
          motivo_cancela: orden.motivo_cancela,    
          client: cliente_id,
          vehicle: vehiculo_id,
          services: orden.services,
          user: orden.user
        } 
        
        console.log('objeto_orden1', newOrden)
        axios.post('http://localhost:4000/api/workorders', newOrden)
        .then((response) => {
          console.log('Data:', response);
          setCliente({...valorInicialCliente});
          setVehiculo({...valorInicialVehiculo});
          setOrden({...valorInicialOrden});
        });
       });
      
    });

  

  }


  return (
    <div className="col-md-6 offset-md-3">
      <div className="card card-body">
        <form onSubmit={guardarDatos}>
          <h2 className="text-center mb-3">Crear Orden</h2>

          <div className="mb-3">
            <label>Estado de la Orden:</label>
            <input
              type="text"
              className="form-control"
              placeholder="Estado de la orden"
              required
              name="estado"
              value={orden.estado}
              onChange={capturarDatosOrden}
            />
          </div>

          <div className="mb-3">
            <label>Cliente:</label>
            <input
              type="text"
              className="form-control"
              placeholder="Nombre del cliente"
              required
              name="nombres"
              value={cliente.nombres}      
              onChange={capturarDatosCliente}        
            />
          </div>

          <div className="mb-3">
            <label>Email:</label>
            <input
              type="text"
              className="form-control"
              placeholder="Email del cliente"
              required
              name="email"
              value={cliente.email}              
              onChange={capturarDatosCliente}        
            />
          </div>

          <div className="mb-3">
            <label>Celular:</label>
            <input
              type="text"
              className="form-control"
              placeholder="Celular del cliente"
              required
              name="celular"
              value={cliente.celular}              
              onChange={capturarDatosCliente}        
            />
          </div>

          <div className="mb-3">
            <label>Identificacion Fiscal:</label>
            <input
              type="text"
              className="form-control"
              placeholder="Identificacion Fiscal del cliente"
              required
              name="identificacionfiscal"
              value={cliente.identificacionfiscal}   
              onChange={capturarDatosCliente}                   
            />
          </div>

          <div className="mb-3">
            <label>Tipo de Identificacion:</label>
            <input
              type="text"
              className="form-control"
              placeholder="Tipo de Identificacion Fiscal del cliente"
              required
              name="tipoid"
              value={cliente.tipoid}              
              onChange={capturarDatosCliente}        
            />
          </div>

          <div className="mb-3">
            <label>Marca:</label>
            <input
              type="text"
              className="form-control"
              placeholder="Marca del vehiculo"
              required
              name="marca"
              value={vehiculo.marca}      
              onChange={capturarDatosVehiculo}                   
            />
          </div>

          <div className="mb-3">
            <label>Modelo:</label>
            <input
              type="text"
              className="form-control"
              placeholder="Modelo del vehiculo"
              required
              name="modelo"
              value={vehiculo.modelo}   
              onChange={capturarDatosVehiculo}                
            />
          </div>

          <div className="mb-3">
            <label>Placa:</label>
            <input
              type="text"
              className="form-control"
              placeholder="Placa del vehiculo"
              required
              name="placa"
              value={vehiculo.placa}            
              onChange={capturarDatosVehiculo}       
            />
          </div>

          <div className="mb-3">
            <label>Nivel del tanque de gasolina:</label>
            <input
              type="text"
              className="form-control"
              placeholder="Nivel del tanque de gasolina del vehiculo"
              required
              name="gasolina"
              value={vehiculo.gasolina}         
              onChange={capturarDatosVehiculo}          
            />
          </div>

          <div className="mb-3">
            <label>Datos exterior del vehiculo:</label>
            <input
              type="text"
              className="form-control"
              placeholder="Datos exterior del vehiculo"
              required
              name="defectos"
              value={vehiculo.defectos}         
              onChange={capturarDatosVehiculo}          
            />
          </div>

          <div className="mb-3">
            <div className="form-check">
              <input
                classNames="form-check-input"
                type="checkbox"
                value=""
                id="flexCheckChecked"
                checked
              />
              <label className="form-check-label" for="flexCheckChecked">
                Cambio de aceite
              </label>
            </div>

            <div className="form-check">
              <input
                classNames="form-check-input"
                type="checkbox"
                value=""
                id="flexCheckChecked"
                checked
              />
              <label className="form-check-label" for="flexCheckChecked">
                Cambio de frenos
              </label>
            </div>

            <div className="form-check">
              <input
                classNames="form-check-input"
                type="checkbox"
                value=""
                id="flexCheckChecked"
                checked
              />
              <label className="form-check-label" for="flexCheckChecked">
                Alineacion y balanceo
              </label>
            </div>

            <div className="form-check">
              <input
                classNames="form-check-input"
                type="checkbox"
                value=""
                id="flexCheckChecked"
                checked
              />
              <label className="form-check-label" for="flexCheckChecked">
                Diagnóstico general
              </label>
            </div>

            <div className="form-check">
              <input
                classNames="form-check-input"
                type="checkbox"
                value=""
                id="flexCheckChecked"
                checked
              />
              <label className="form-check-label" for="flexCheckChecked">
                Revisión sistema eléctrica
              </label>
            </div>

            <div className="form-check">
              <input
                classNames="form-check-input"
                type="checkbox"
                value=""
                id="flexCheckChecked"
                checked
              />
              <label className="form-check-label" for="flexCheckChecked">
                Revisión de la suspensión
              </label>
            </div>
          </div>

          <div className="mb-3">
            <label>Motivo de la cancelación de la orden:</label>
            <input
              type="text"
              className="form-control"
              placeholder="Motivo de Nivel de la cancelación de la orden"
              required
              name="motivo_cancela"
              value={orden.motivo_cancela}    
              onChange={capturarDatosOrden}                   
            />
          </div>

          <div className="mb-3">
            <label>ID Usuario:</label>
            <input
              type="text"
              className="form-control"
              placeholder="ID del usuario"
              required
              name="user"
              value={orden.user}                   
              onChange={capturarDatosOrden}                   
            />
          </div>

          <div className="mb-3">
            <label>Nombre del Usuario:</label>
            <input
              type="text"
              className="form-control"
              placeholder="Nombre del usuario"
              required
            />
          </div>

          <button className="btn btn-primary form-control">Enviar Orden</button>
        </form>
      </div>
    </div>
  );
};

export default CrearOrdenes;
