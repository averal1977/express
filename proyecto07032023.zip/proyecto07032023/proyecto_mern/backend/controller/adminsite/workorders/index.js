const express = require('express');
const router = express.Router();

const Orders = require('../../../models/workorders');
const Clients = require('./../../../models/clients');

router.get('/', (req, res) => {
    console.log('Client:', req.session.client)
    if (req.session.client) {
        return res.render('admin/index', { name: 'Administrator'});
    }
    return res.render('admin/login');
});

router.post('/login', (req, res) => {
    const { 
        email, 
        password
    } = req.body;

    console.log('Email:', email, 'Password:', password);

    Clients.getClientByEmail(email, (error, client) => {
        if(error) {
            return  res.status(500).json({ code: 'UE' , message: 'Unknown Error!'})
        }
        console.log('Client:', client)
        if (client.clave == password) {

            req.session.client = client.toJSON();

            return req.session.save(function (err) {
                if (err) return  res.status(500).json({ code: 'UE' , message: 'Unknown Error!'})
                console.log('Success:', client)
                // return res.json({ code: 'OK', message: 'Login successful!'})
                return res.redirect('/');
            });
        }
        
        return res.status(421).json({ code: 'PF' , message: 'Email or password is incorrect!'})
    });
});

router.get('/api/workorders', (req, res) => {
    return Orders.getOrder((error, elems)=> {
        if (error) {
            return res.status(500).json({ code: 'UE', message: 'Unknown error'})
        }
        res.json(elems);
    });
});

router.post('/api/workorders', function (req, res){
    const order = req.body;
    console.log('Data:', order);

    return Orders.createOrder(order, (error, b) => {
        if(error){
            return  res.status(500).json({ code: 'UE', message: 'Unkwown error'})
        }
        res.json({ code: 'OK', message: 'Saved successfully!', data: b.toJSON()})
    });
});

router.put('/api/workorders/:id', (req, res) => {
    const order = req.body;
    console.log('Data:', order);
    const {id} = req.params;
    console.log('id', id);
    Orders.updateOrder(id, order, (error, b) => {
        if (error) {
            return  res.status(500).json({ code: 'UE', message: 'Unkwown error'})
        }
        res.json({ code: 'OK', message: 'Update successfully!', data: b.toJSON()})
    });
});

router.delete('/api/workorders/:id', function (req, res){
    console.log('Deleting:', req.params);
    const { id } = req.params;
    
    Orders.deleteOrder(id, (error, b) => {
        if (error) {
            return  res.status(500).json({ code: 'UE', message: 'Unkwown error'})
        }
        res.json({ code: 'OK', message: 'Deleted successfully!', data: b.toJSON()})
    });
});


module.exports = router;
