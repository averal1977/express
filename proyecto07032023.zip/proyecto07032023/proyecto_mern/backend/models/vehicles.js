const Vehicles = require('../schemas/vehicles');

function getVehicle(cb) {
    Vehicles.find({})
    .then((elems) => {
        return cb(null, elems);
    })
    .catch((error) => {
        console.log('Error:', error);
        return cb(error);
    })
}

function createVehicle(b, cb) {
    new Vehicles(b)
    .save()
    .then((elem) => {
        return cb(null, elem);
    })
    .catch((error) => {
        console.log('Error:', error);
        return cb(error);
    });
}

function deleteVehicle(id, cb) {
    Vehicles.findOneAndRemove({ _id: id})
    .then((elem) => {
        return cb(null, elem);
    })
    .catch((error) => {
        console.log('Error:', error);
        return cb(error);
    })
}

function updateVehicle(id, vehicle, cb) {
    Orders.findOneAndUpdate({ _id: id}, vehicle)
    .then((elem) => {
        return cb(null, elem);
    })
    .catch((error) => {
        console.log('Error:', error);
        return cb(error);
    })
}

exports.getVehicle = getVehicle;
exports.createVehicle = createVehicle;
exports.deleteVehicle = deleteVehicle;
exports.updateVehicle = updateVehicle;
