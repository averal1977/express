import React, { useEffect, useState } from 'react'
import axios from 'axios'

const ListaOrdenes = () => {
  const [lista, setLista] = useState([])

  useEffect(()=>{
    const getOrdenes = async() => {
        const res = await axios.get('http://localhost:4000/api/workorders')
        setLista(res.data)
    }
    getOrdenes();
  },[lista])

/*
  useEffect(() => {
    axios("http://localhost:4000/api/workorders")
      .then((response) =>
        response.data.map((orden) => ({
          id: orden._id,
          estado: orden.estado,
        }))
      )
      .then((data) => {
        setLista(data);
      });
  }, [lista]);
*/

const eliminarOrden = async(id_orden, id_cliente, id_vehiculo)=>{
  console.log('cliente', id_cliente)
  console.log('vehiculo', id_vehiculo)
  console.log('vehiculo', id_orden)
  await axios.delete('http://localhost:4000/api/workorders/' + id_orden)
  await axios.delete('http://localhost:4000/api/clients/' + id_cliente)
  await axios.delete('http://localhost:4000/api/vehicles/' + id_vehiculo)

}

  return (
    <div className='row'>
      {
        lista.map(list => (
            <div className='col-md-4 p-2' key={list._id}>
              <div className='card'>
                <div className='card-header'>
                  <h5>Orden: {list._id}</h5>
                </div>  
                <div className='card-body'>
                  <p>Cliente: {list.client.nombres}</p>
                  <p>Vehiculo-Marca: {list.vehicle.marca}</p>
                  <p>Vehiculo-Modelo: {list.vehicle.modelo}</p>
                  <p>Vehiculo-Placa: {list.vehicle.placa}</p>
                  <p>Servicio: {list.services[0]}</p>
                  <p>Estado: {list.estado}</p>
                  <p>User: {list.user.nombres}</p>
                  <p>User-Nombre: {list.user.nombres}</p>      
                  <p>User-Email: {list.user.email}</p>                  
                </div>  
                <div className='card-footer'>
                    <button className='btn btn-danger' onClick={()=>eliminarOrden(list._id, list.client._id, list.vehicle._id)}>
                      Eliminar
                    </button>
                </div>

              </div>  
            </div>
        ))
      }
    </div>
  )
}

export default ListaOrdenes