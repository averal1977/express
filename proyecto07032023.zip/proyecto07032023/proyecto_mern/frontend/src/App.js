import './App.css';
import {Routes, Route} from 'react-router-dom'
import Navegacion from './components/Navegacion'
import CrearOrdenes from './components/CrearOrdenes';
import ListaOrdenes from './components/ListaOrdenes';

function App() {
  return (
    <div className="">
      <Navegacion/>
        <div className='container p-4'>
          <Routes>
            <Route path = "/" element={<ListaOrdenes/>} />
            <Route path = "/CrearOrden" element={<CrearOrdenes/>} />
            <Route path = "/edit/:id" element={<CrearOrdenes/>} />
          </Routes>
        </div>
    </div>
  );
}

export default App;
