const express = require('express');
const router = express.Router();

const Users = require('../../../models/users');


router.get('/api/users', (req, res) => {
    return Users.getUser((error, elems)=> {
        if (error) {
            return res.status(500).json({ code: 'UE', message: 'Unknown error'})
        }
        res.json(elems);
    });
});

router.post('/api/users', function (req, res){
    const client = req.body;
    console.log('Data:', client);

    return Users.createUser(client, (error, b) => {
        if(error){
            return  res.status(500).json({ code: 'UE', message: 'Unkwown error'})
        }
        res.json({ code: 'OK', message: 'Saved successfully!', data: b.toJSON()})
    });
});


router.delete('/api/users/:id', function (req, res){
    console.log('Deleting:', req.params);
    const { id } = req.params;
    
    Users.deleteUser(id, (error, b) => {
        if (error) {
            return  res.status(500).json({ code: 'UE', message: 'Unkwown error'})
        }
        res.json({ code: 'OK', message: 'Deleted successfully!', data: b.toJSON()})
    });
});

router.put('/api/users/:id', (req, res) => {
    const client = req.body;
    console.log('Data:', client);
    const {id} = req.params;
    console.log('id', id);
    Orders.updateUser(id, client, (error, b) => {
        if (error) {
            return  res.status(500).json({ code: 'UE', message: 'Unkwown error'})
        }
        res.json({ code: 'OK', message: 'Update successfully!', data: b.toJSON()})
    });
});

module.exports = router;
