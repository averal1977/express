require('dotenv').config()
const express = require('express');
const app = express();
const engine = require('ejs-locals');
const cors = require('cors');
const bodyParser = require('body-parser');
//const cookieSession = require("cookie-session");
const session = require('express-session');
const path = require('path');

//ejecutar el servidor
const db = require('./database');

const AdminOrderCarShop = require('./controller/adminsite/workorders')
const AdminClientCarShop = require('./controller/adminsite/clients')
const AdminVehicleCarShop = require('./controller/adminsite/vehicles')
const AdminServiceCarShop = require('./controller/adminsite/services')
const AdminUserCarShop = require('./controller/adminsite/users')
const AdminRoleCarShop = require('./controller/adminsite/roles')
const AdminAuthCarShop = require('./controller/adminsite/auths')


app.use(bodyParser.json({ type: 'application/json' }))
// Use the session middleware
app.use(session({ 
    secret: 'Thisisthepassword', 
    resave: false,
    saveUninitialized: true
}))

app.engine('ejs', engine);
app.set('views', __dirname + '/views');
app.set('view engine', 'ejs');
app.use(cors({origin: '*'}));

//rutas
app.use('/', AdminUserCarShop)
app.use('/', AdminClientCarShop)
app.use('/', AdminVehicleCarShop);
app.use('/', AdminServiceCarShop);
app.use('/', AdminRoleCarShop)
app.use('/', AdminOrderCarShop);
app.use('/', AdminAuthCarShop);


app.use(express.static(path.join(__dirname, "build")));

//configuracion
app.set('port', process.env.PORT || 4000)
app.listen(4000, () => console.log('Example app listening on port: ', app.get('port')))
