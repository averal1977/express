const express = require('express');
const app = express();
const engine = require('ejs-locals');
const bodyParser = require('body-parser');
const session = require('express-session')

const path = require('path');

//const db = require('./db');

const ClientOrderCarShop = require('./controllers/clientsite/workorders')

app.use(bodyParser.json({ type: 'application/json' }))

const fMiddleware = (request, response, next ) => {
    const date = new Date();
    console.log(`It's my time: ${date}`);
    next();
}

// Use the session middleware
app.use(session({ 
    secret: 'Thisisthepassword', 
    cookie: { maxAge: 60000 }
}))

app.use(fMiddleware);

app.use((request, response, next) => {

    const { client } = request.session
    console.log('Cliente is:', client);
    next();
})

app.use((request, response, next) => {

    const client = {
        name: 'Alex',
        last: 'Vera'
    }
    request.session.client = client;
    next();
});

app.engine('ejs', engine);
app.set('views', __dirname + '/views');
app.set('view engine', 'ejs');

app.use('/', ClientOrderCarShop);

app.use(express.static(path.join(__dirname, "build")));

//const PORT = 3002;
//app.listen(PORT, () => console.log(`Example app listening on port ${PORT}!`))
//configuracion
app.set('port', process.env.PORT || 3002)
app.listen(3002, () => console.log('Example app listening on port: ', app.get('port')))

