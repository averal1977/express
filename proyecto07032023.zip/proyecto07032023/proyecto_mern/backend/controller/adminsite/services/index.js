const express = require('express');
const router = express.Router();

const Services = require('../../../models/services');


router.get('/api/services', (req, res) => {
    return Services.getService((error, elems)=> {
        if (error) {
            return res.status(500).json({ code: 'UE', message: 'Unknown error'})
        }
        res.json(elems);
    });
});

router.post('/api/services', function (req, res){
    const service = req.body;
    console.log('Data:', service);

    return Services.createService(service, (error, b) => {
        if(error){
            return  res.status(500).json({ code: 'UE', message: 'Unkwown error'})
        }
        res.json({ code: 'OK', message: 'Saved successfully!', data: b.toJSON()})
    });
});


router.delete('/api/services/:id', function (req, res){
    console.log('Deleting:', req.params);
    const { id } = req.params;
    
    Services.deleteService(id, (error, b) => {
        if (error) {
            return  res.status(500).json({ code: 'UE', message: 'Unkwown error'})
        }
        res.json({ code: 'OK', message: 'Deleted successfully!', data: b.toJSON()})
    });
});

router.put('/api/services/:id', (req, res) => {
    const service = req.body;
    console.log('Data:', service);
    const {id} = req.params;
    console.log('id', id);
    Orders.updateService(id, service, (error, b) => {
        if (error) {
            return  res.status(500).json({ code: 'UE', message: 'Unkwown error'})
        }
        res.json({ code: 'OK', message: 'Update successfully!', data: b.toJSON()})
    });
});

module.exports = router;
