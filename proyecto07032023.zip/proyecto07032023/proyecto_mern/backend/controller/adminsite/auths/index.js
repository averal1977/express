const express = require('express');
const router = express.Router();

const Auths = require('../../../models/auths');


router.get('/api/auths', (req, res) => {
//router.get('/api/workorders', (req, res) => {    
    return Auths.getAuth((error, elems)=> {
        if (error) {
            return res.status(500).json({ code: 'UE', message: 'Unknown error'})
        }
        res.json(elems);
    });
});

router.post('/api/auths', function (req, res){
    const client = req.body;
    console.log('Data:', client);

    return Auths.createAuth(client, (error, b) => {
        if(error){
            return  res.status(500).json({ code: 'UE', message: 'Unkwown error'})
        }
        res.json({ code: 'OK', message: 'Saved successfully!', data: b.toJSON()})
    });
});


router.delete('/api/auths/:id', function (req, res){
    console.log('Deleting:', req.params);
    const { id } = req.params;
    
    Auths.deleteAuth(id, (error, b) => {
        if (error) {
            return  res.status(500).json({ code: 'UE', message: 'Unkwown error'})
        }
        res.json({ code: 'OK', message: 'Deleted successfully!', data: b.toJSON()})
    });
});

router.put('/api/auths/:id', (req, res) => {
    const client = req.body;
    console.log('Data:', client);
    const {id} = req.params;
    console.log('id', id);
    Orders.updateAuth(id, client, (error, b) => {
        if (error) {
            return  res.status(500).json({ code: 'UE', message: 'Unkwown error'})
        }
        res.json({ code: 'OK', message: 'Update successfully!', data: b.toJSON()})
    });
});

module.exports = router;
