const Auths = require('../schemas/auths');

function getAuth(cb) {
    Auths.find({})
    .then((elems) => {
        return cb(null, elems);
    })
    .catch((error) => {
        console.log('Error:', error);
        return cb(error);
    })
}

function createAuth(b, cb) {
    new Auths(b)
    .save()
    .then((elem) => {
        return cb(null, elem);
    })
    .catch((error) => {
        console.log('Error:', error);
        return cb(error);
    });
}

function deleteAuth(id, cb) {
    Auths.findOneAndRemove({ _id: id})
    .then((elem) => {
        return cb(null, elem);
    })
    .catch((error) => {
        console.log('Error:', error);
        return cb(error);
    })
}

function getPassword(cb) {
    Auths.find({esquema: 'basic-auth'})
    .then(elem => {
        return cb(null, elem[0]);
    })
    .catch((error) => {
        console.log('Error:', error);
        return cb(error);
    })
}

exports.createAuth = createAuth;
exports.getAuth = getAuth;
exports.deleteAuth = deleteAuth;
exports.getPassword = getPassword;