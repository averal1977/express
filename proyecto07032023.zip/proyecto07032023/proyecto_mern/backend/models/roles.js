const Roles = require('../schemas/Roles');

function getRole(cb) {
    Roles.find({})
    .then((elems) => {
        return cb(null, elems);
    })
    .catch((error) => {
        console.log('Error:', error);
        return cb(error);
    })
}

function getRoleByEmail(emailValue, cb) {
    Roles.findOne({ email: emailValue})
    .then((elem) => {
        return cb(null, elem);
    })
    .catch((error) => {
        console.log('Error:', error);
        return cb(error);
    })
}


function createRole(b, cb) {
    new Roles(b)
    .save()
    .then((elem) => {
        return cb(null, elem);
    })
    .catch((error) => {
        console.log('Error:', error);
        return cb(error);
    });
}

function deleteRole(id, cb) {
    Roles.findOneAndRemove({ _id: id})
    .then((elem) => {
        return cb(null, elem);
    })
    .catch((error) => {
        console.log('Error:', error);
        return cb(error);
    })
}

function updateRole(id, role, cb) {
    Orders.findOneAndUpdate({ _id: id}, role)
    .then((elem) => {
        return cb(null, elem);
    })
    .catch((error) => {
        console.log('Error:', error);
        return cb(error);
    })
}

exports.getRole = getRole;
exports.getRoleByEmail = getRoleByEmail;
exports.createRole = createRole;
exports.deleteRole = deleteRole;
exports.updateRole = updateRole;
