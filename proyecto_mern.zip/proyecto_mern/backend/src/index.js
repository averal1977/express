require('dotenv').config()
const express = require('express');
const app = express();
const engine = require('ejs-locals');
//const cors = require('cors');
const bodyParser = require('body-parser');
//const cookieSession = require("cookie-session");
const session = require('express-session');
const path = require('path');

//ejecutar el servidor
const db = require('./database');

const ClientCarShop = require('./controller/adminsite/clients')
const VehicleCarShop = require('./controller/adminsite/vehicles')
const ServiceCarShop = require('./controller/adminsite/services')
const OrderCarShop = require('./controller/adminsite/orders')


app.use(bodyParser.json({ type: 'application/json' }))
app.use(session({ 
    secret: 'Thisisthepassword', 
    resave: false,
    saveUninitialized: true
}))


app.engine('ejs', engine);
app.set('views', __dirname + '/views');
app.set('view engine', 'ejs');

//rutas
app.use('/client', ClientCarShop);
app.use('/vehicle', VehicleCarShop);
app.use('/service', ServiceCarShop);
app.use('/order', OrderCarShop);



app.use(express.static(path.join(__dirname, "build")));

//configuracion
app.set('port', process.env.PORT || 4000)
app.listen(4000, () => console.log('Example app listening on port: ', app.get('port')))
