const mongoose = require('mongoose');

const vehiclesSchema = mongoose.Schema({
    marca: {
        type: String,
        required: false      
    },
    modelo: {
        type: String,
        required: false      
    },
    placa: {
        type: String,
        required: false      
    },
    gasolina: {
        type: String,
        required: false      
    },
    defectos: {
        type: String,
        required: false      
    },
});

const Vehicles = new mongoose.model('Vehicle', vehiclesSchema);

module.exports = Vehicles;
