const express = require('express');
const router = express.Router();

const Roles = require('../../../models/roles');


router.get('/api/roles', (req, res) => {
    return Roles.getRole((error, elems)=> {
        if (error) {
            return res.status(500).json({ code: 'UE', message: 'Unknown error'})
        }
        res.json(elems);
    });
});

router.post('/api/roles', function (req, res){
    const client = req.body;
    console.log('Data:', client);

    return Roles.createRole(client, (error, b) => {
        if(error){
            return  res.status(500).json({ code: 'UE', message: 'Unkwown error'})
        }
        res.json({ code: 'OK', message: 'Saved successfully!', data: b.toJSON()})
    });
});


router.delete('/api/roles/:id', function (req, res){
    console.log('Deleting:', req.params);
    const { id } = req.params;
    
    Roles.deleteRole(id, (error, b) => {
        if (error) {
            return  res.status(500).json({ code: 'UE', message: 'Unkwown error'})
        }
        res.json({ code: 'OK', message: 'Deleted successfully!', data: b.toJSON()})
    });
});

router.put('/api/roles/:id', (req, res) => {
    const client = req.body;
    console.log('Data:', client);
    const {id} = req.params;
    console.log('id', id);
    Orders.updateRole(id, client, (error, b) => {
        if (error) {
            return  res.status(500).json({ code: 'UE', message: 'Unkwown error'})
        }
        res.json({ code: 'OK', message: 'Update successfully!', data: b.toJSON()})
    });
});

module.exports = router;
