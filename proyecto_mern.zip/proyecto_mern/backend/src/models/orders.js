const Orders = require('../schemas/orders');

function getOrder(cb) {
    Orders.find({})
    .then((elems) => {
        return cb(null, elems);
    })
    .catch((error) => {
        console.log('Error:', error);
        return cb(error);
    })
}

function createOrder(b, cb) {
    new Orders(b)
    .save()
    .then((elem) => {
        return cb(null, elem);
    })
    .catch((error) => {
        console.log('Error:', error);
        return cb(error);
    });
}

function deleteOrder(id, cb) {
    Orders.findOneAndRemove({ _id: id})
    .then((elem) => {
        return cb(null, elem);
    })
    .catch((error) => {
        console.log('Error:', error);
        return cb(error);
    })
}

exports.getOrder = getOrder;
exports.createOrder = createOrder;
exports.deleteOrder = deleteOrder;
